# Advanced WPPerformance

## Description
This plugin add several performance improvements to your WordPress site.

## Changelog

### 0.0.1
* Initial version from 2014

## Contributors
* Nico Martin | [nicomartin.ch](https://www.nicomartin.ch)

## License
