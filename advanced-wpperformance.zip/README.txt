=== PLUGIN_NAME ===
Contributors: Nico Martin (nico-martin)
Donate link: https://www.paypal.me/NicoMartin
Tags: Performance
Requires at least: 4.7
Tested up to: 4.7.3
Stable tag: 0.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

This plugin add several performance improvements to your WordPress site.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Any other installation instuctions.

== Changelog ==

= 0.0.1 =
* Initial development version.
